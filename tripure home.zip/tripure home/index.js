function show(){
    let get=document.getElementById("getid")
    get.style.display="block";
}
function hide(){
    let get=document.getElementById("getid")
    get.style.display="none";
}
let slidercontainer=document.getElementById('slidercontainer');
let slider=document.getElementById('slider');
let cards=slider.getElementsByTagName('li');
let elementToshow=3;
if(document.body.clientWidth<900){
    elementToshow=1;
}
else if(document.body.clientWidth<1000){
    elementToshow=2;
}
let slidercontainerwidth=slidercontainer.clientWidth;
let cardwidth=slidercontainerwidth/elementToshow;
slider.style.width=cards.length*cardwidth+'px';
slider.style.transition='margin';
slider.style.transitionDuration='1s'; 
slider.style.transition='margin';
slider.style.transitionDuration='1s';
for (let index=0; index<cards.length;index++){
    const element=cards[index];
    element.style.width=cardwidth+'px';
}
function prev(){
    if(+slider.style.marginLeft.slice(0,-2)!= -cardwidth*(cards.length-elementToshow))
    slider.style.marginLeft=((+slider.style.marginLeft.slice(0,-2))-cardwidth)+'px';
}
function next(){
    if(+slider.style.marginLeft.slice(0,-2)!=0)
    slider.style.marginLeft =((+slider.style.marginLeft.slice(0,-2))+cardwidth)+'px';
    
}
